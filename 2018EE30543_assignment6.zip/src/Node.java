

public class Node<T extends Comparable>  {

	T value;
	Node<T> next;
	Node(T v){
		this.value=v;
		next=null;
	}
	
	
	
	
	
	
	
}
